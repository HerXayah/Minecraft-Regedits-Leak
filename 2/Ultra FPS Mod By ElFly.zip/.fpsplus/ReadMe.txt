Open as a archive with 7zip. All of the files should be the newest avaliable ones, 1.7.10 only works with mcp. I'll try to work on the mod when I can but there will be no gurantee of a update.
